package edu.buffalo.cse.cse486586.groupmessenger;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;

import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;

import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class GroupMessengerActivity extends Activity {
	public final static String TAG="tag";
	
	int count=0;
	ServerSocket server;
	Socket serverSock;
	BufferedReader inputs;
	String inputLine;
	String portStr;
	Socket sock;
	DataOutputStream output = null;
	String ipAdd="10.0.2.2";
	int currentVal[]={0,0,0};
	int newVal[]={0,0,0};
	int avd0=0;
	int avd1=0;
	int avd2=0;
	int testNo;
	String msg="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_group_messenger);
		TextView tv = (TextView) findViewById(R.id.textView1);
		tv.setMovementMethod(new ScrollingMovementMethod());

		findViewById(R.id.button1).setOnClickListener(
				new OnPTestClickListener(tv, getContentResolver()));

		TelephonyManager tel =(TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
		portStr= tel.getLine1Number().substring(tel.getLine1Number().length() - 4);

		findViewById(R.id.button2).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Client c=new Client("Test1",5);
				c.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);					
			}
		});

		findViewById(R.id.button3).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Client c=new Client("Test1",0);
				c.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);					
			}
		});


		Server s= new Server();
		s.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		Log.v(TAG, "Server instantiated successfully");

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
		return true;

	}

	public class Client extends AsyncTask<Void, Void, Void>{

		public int nMssg;
		public Client(String test ,int noMssg)
		{
			if(noMssg==5 && test.equals("Test1"))
				testNo=1;
			else
				testNo = 2;

			nMssg=noMssg;
		}
		@Override
		protected Void doInBackground(Void... para)
		{
			try
			{

				for(int i=0;i<nMssg;i++)
				{	
					msg=assignValIncrementVal(portStr, currentVal, msg);

					sock = new Socket(InetAddress.getByName(ipAdd),11108);
					output = new DataOutputStream(sock.getOutputStream());
					output.writeBytes(msg);
					sock.close();

					if(testNo==1)
						Thread.sleep(3000);
				}


				if(testNo==2)
				{
					if(nMssg==0)
					{
						msg=assignValIncrementVal(portStr, currentVal, msg);
						sock = new Socket(InetAddress.getByName(ipAdd),11108);
						output = new DataOutputStream(sock.getOutputStream());
						msg=msg+"Test2";
						output.writeBytes(msg);
						sock.close();
					}
				}



			}
			catch(Exception e){} 
			return null;
		}

		protected void onPostExecute(String result) {
		}

		protected void onPreExecute() {
		}

		protected void onProgressUpdate(Void... values) {

		}
	}

	public class Server extends AsyncTask<Void, String, Void>{

		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub

			//super.onProgressUpdate(values);
			TextView txtView = (TextView) findViewById(R.id.textView1);
			txtView.append(values[0]+"\n");

		}
		@Override
		protected Void doInBackground(Void... values)
		{
			Log.v(TAG, "Inside Server instantiated successfully");
			server = null;
			serverSock = null;
			inputs = null;

			try
			{
				server = new ServerSocket(10000);
				Log.v(TAG, "Server Socket Created");
				while(true)
				{
					serverSock = server.accept();
					Log.v(TAG, "Call Accepted:"+serverSock.toString());
					inputs = new BufferedReader(new InputStreamReader(serverSock.getInputStream()));
					Log.v(TAG, "Got Input Stream");
					if(inputs!=null)
						inputLine = inputs.readLine();
					Log.v("Print Input Stream", inputLine);

					if(inputLine.contains("Test2"))
					{
						Client client=new Client("Test2",2);
						client.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
					}

					if(portStr.equals("5554"))//avd0 acting like a sequencer
					{
						String seQ = sequencerCall(inputLine, currentVal);
						if(seQ.equals("OK"))
						{
							for(int i=4;i<=8;i+=4)
							{
								sock = new Socket(InetAddress.getByName(ipAdd),11108+i);
								output = new DataOutputStream(sock.getOutputStream());
								output.writeBytes(inputLine);
								sock.close();
							}

						}
					}
					
					
					if(inputLine.contains("Test2"))
					{
						String publish=inputLine.substring(0,6);
						publishProgress(publish);
					}
					else
						publishProgress(inputLine);

				}
			}
			catch(IOException e)
			{

			} 

			try {
				if (serverSock != null) 
					serverSock.close();

			} catch (final IOException ex) {
			}

			try {
				if (server != null) 
					server.close();

			} catch (final IOException ex) {
			}
			return null;
		}

		protected void onPostExecute(String result) {
		}

		protected void onPreExecute() {
		}

		public String sequencerCall(String message, int[] currentVal)
		{
			count=0;
			for(int i=0;i<3;i++)
			{
				if((newVal[i]-currentVal[i])==1 || (newVal[i]-currentVal[i])==-1)
					count++;
			}
			if(count==1 || count==0)
			{
				for(int i=0;i<3;i++)
				{
					newVal[i]=currentVal[i];
				}
				return "OK";
			}
			
			else
			return "NOT OK";
		}
	}

	public String assignValIncrementVal(String portStr, int []currentVal, String msg)
	{
		if(portStr.equals("5554"))
		{
			msg="avd0:"+avd0;
			avd0++;
			currentVal[0]+=1;

		}
		if(portStr.equals("5556")){
			msg="avd1:"+avd1;
			avd1++;
			currentVal[1]+=1;

		}
		if(portStr.equals("5558")){
			msg="avd2:"+avd2;
			avd2++;
			currentVal[2]+=1;

		}

		return msg;
	}

}




