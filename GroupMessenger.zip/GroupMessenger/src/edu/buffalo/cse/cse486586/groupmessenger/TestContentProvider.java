package edu.buffalo.cse.cse486586.groupmessenger;
import java.io.*;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.util.Log;


public class TestContentProvider extends ContentProvider{
	
	@Override
	public int delete(Uri arg0, String arg1, String[] arg2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType(Uri arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri arg0, ContentValues arg1) {
		// TODO Auto-generated method stub
		FileOutputStream fos;
		Context c = getContext();
		String fileName=arg1.get("key").toString();	
		
			try{				
			fos=c.openFileOutput(fileName, Context.MODE_PRIVATE);
			fos.write(arg1.get("value").toString().getBytes());
			fos.close();
			}
		 catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		

		return null;
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Cursor query(Uri arg0, String[] arg1, String arg2, String[] arg3,
			String arg4) {
		// TODO Auto-generated method stub
		FileInputStream fis;
		Context c=getContext();
		MatrixCursor mCursor=new MatrixCursor(new String[]{"key","value"});
		try {
			fis=c.openFileInput(arg2);
			String output="";
			BufferedReader br=new BufferedReader(new InputStreamReader(fis));
			output=br.readLine();
			br.close();
			mCursor.addRow(new String[]{arg2,output});
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return mCursor;
	}

	@Override
	public int update(Uri arg0, ContentValues arg1, String arg2, String[] arg3) {
		// TODO Auto-generated method stub
		return 0;
	}

}
